package com.Problem_Statement_3_1;

public abstract class Instrument {
	public abstract void play();
}




